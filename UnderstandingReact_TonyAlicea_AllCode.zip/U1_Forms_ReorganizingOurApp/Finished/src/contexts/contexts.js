import { createContext } from 'react';

export const CounterContext = createContext(null);
export const CounterDispatchContext = createContext(null);
export const TabContext = createContext(null);
export const TabDispatchContext = createContext(null);
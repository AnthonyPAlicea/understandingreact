import { CounterSummary } from './CounterSummary.jsx';

export function CounterTools() {
    return (
        <CounterSummary />
    )
}
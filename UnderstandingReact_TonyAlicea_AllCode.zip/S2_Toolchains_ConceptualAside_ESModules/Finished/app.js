import { CounterObj } from "./otherCode.js";

const counters = [
    new CounterObj(1, 'A', 1, 0),
    new CounterObj(2, 'B', 2, 0),
    new CounterObj(3, 'C', 1, 0)
];

console.log(counters);